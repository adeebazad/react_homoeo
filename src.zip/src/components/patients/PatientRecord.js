import React, { useState, useEffect } from 'react';
import {
  Container,
  Paper,
  Typography,
  Grid,
  TextField,
  Button,
  Box,
  Alert,
} from '@mui/material';
import { patientService } from '../../services/patient.service';

const PatientRecord = () => {
  const [record, setRecord] = useState(null);
  const [updateRequest, setUpdateRequest] = useState({
    field_name: '',
    current_value: '',
    requested_value: '',
    reason: '',
  });
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');

  useEffect(() => {
    loadPatientRecord();
  }, []);

  const loadPatientRecord = async () => {
    try {
      const data = await patientService.getPatientRecord();
      if (data.results && data.results.length > 0) {
        setRecord(data.results[0]);
      }
    } catch (err) {
      setError('Failed to load patient record');
    }
  };

  const handleUpdateRequest = async (fieldName) => {
    try {
      const currentValue = record[fieldName] || '';
      await patientService.createUpdateRequest({
        field_name: fieldName,
        current_value: currentValue,
        requested_value: updateRequest.requested_value,
        reason: updateRequest.reason,
      });
      setSuccess('Update request submitted successfully');
      setUpdateRequest({
        field_name: '',
        current_value: '',
        requested_value: '',
        reason: '',
      });
    } catch (err) {
      setError('Failed to submit update request');
    }
  };

  if (!record) {
    return <Typography>Loading...</Typography>;
  }

  return (
    <Container maxWidth="md" sx={{ mt: 4 }}>
      {error && (
        <Alert severity="error" sx={{ mb: 2 }}>
          {error}
        </Alert>
      )}
      {success && (
        <Alert severity="success" sx={{ mb: 2 }}>
          {success}
        </Alert>
      )}
      <Paper elevation={3} sx={{ p: 3 }}>
        <Typography variant="h4" gutterBottom>
          Medical Record
        </Typography>
        <Grid container spacing={3}>
          <Grid item xs={12}>
            <Typography variant="h6">Blood Group</Typography>
            <Typography>{record.blood_group || 'Not specified'}</Typography>
          </Grid>
          <Grid item xs={12}>
            <Typography variant="h6">Allergies</Typography>
            <Typography>{record.allergies || 'None reported'}</Typography>
          </Grid>
          <Grid item xs={12}>
            <Typography variant="h6">Medical History</Typography>
            <Typography>{record.medical_history || 'No history recorded'}</Typography>
          </Grid>
          <Grid item xs={12}>
            <Typography variant="h6">Current Medications</Typography>
            <Typography>
              {record.current_medications || 'No current medications'}
            </Typography>
          </Grid>
        </Grid>

        <Box sx={{ mt: 4 }}>
          <Typography variant="h5" gutterBottom>
            Request Update
          </Typography>
          <Grid container spacing={2}>
            <Grid item xs={12}>
              <TextField
                fullWidth
                label="New Value"
                value={updateRequest.requested_value}
                onChange={(e) =>
                  setUpdateRequest({
                    ...updateRequest,
                    requested_value: e.target.value,
                  })
                }
              />
            </Grid>
            <Grid item xs={12}>
              <TextField
                fullWidth
                label="Reason for Update"
                multiline
                rows={4}
                value={updateRequest.reason}
                onChange={(e) =>
                  setUpdateRequest({ ...updateRequest, reason: e.target.value })
                }
              />
            </Grid>
            <Grid item xs={12}>
              <Button
                variant="contained"
                onClick={() => handleUpdateRequest('medical_history')}
              >
                Submit Update Request
              </Button>
            </Grid>
          </Grid>
        </Box>
      </Paper>
    </Container>
  );
};

export default PatientRecord;
