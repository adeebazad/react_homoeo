import React from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { ThemeProvider, createTheme } from '@mui/material';
import CssBaseline from '@mui/material/CssBaseline';
import { AuthProvider } from './contexts/AuthContext';
import PrivateRoute from './components/common/PrivateRoute';
import DoctorRoute from './components/common/DoctorRoute';
import Header from './components/common/Header';
import Home from './components/home/Home';
import Login from './components/auth/Login';
import Register from './components/auth/Register';
import Dashboard from './components/dashboard/Dashboard';
import PatientRecord from './components/patients/PatientRecord';
import UpdateRequests from './components/patients/UpdateRequests';
import Appointments from './components/appointments/Appointments';
import BlogPost from './components/blog/BlogPost';
import BlogList from './components/blog/BlogList';
import CreateBlogPost from './components/blog/CreateBlogPost';
import './App.css';

const theme = createTheme({
  palette: {
    primary: {
      main: '#1976d2',
    },
    secondary: {
      main: '#dc004e',
    },
  },
});

function App() {
  return (
    <ThemeProvider theme={theme}>
      <CssBaseline />
      <AuthProvider>
        <Router>
          <Header />
          <Routes>
            {/* Public Routes */}
            <Route path="/" element={<Home />} />
            <Route path="/login" element={<Login />} />
            <Route path="/register" element={<Register />} />
            <Route path="/blog" element={<BlogList />} />
            <Route path="/blog/:slug" element={<BlogPost />} />
            <Route path="/blog/create" element={
              <DoctorRoute>
                <CreateBlogPost />
              </DoctorRoute>
            } />

            {/* Protected Routes */}
            <Route
              path="/dashboard"
              element={
                <PrivateRoute>
                  <Dashboard />
                </PrivateRoute>
              }
            />
            <Route
              path="/medical-records"
              element={
                <PrivateRoute>
                  <PatientRecord />
                </PrivateRoute>
              }
            />
            <Route
              path="/update-requests"
              element={
                <DoctorRoute>
                  <UpdateRequests />
                </DoctorRoute>
              }
            />
            <Route
              path="/appointments"
              element={
                <PrivateRoute>
                  <Appointments />
                </PrivateRoute>
              }
            />
            <Route
              path="/blog/create"
              element={
                <DoctorRoute>
                  <BlogPost isCreate={true} />
                </DoctorRoute>
              }
            />
          </Routes>
        </Router>
      </AuthProvider>
    </ThemeProvider>
  );
}

export default App;
