import api from './api';

export const patientService = {  getPatientRecord: async () => {
    const response = await api.get('/api/patients/record/');
    return response.data;
  },

  updatePatientRecord: async (id, data) => {
    const response = await api.patch(`/patient-records/${id}/`, data);
    return response.data;
  },

  createUpdateRequest: async (data) => {
    const response = await api.post('/update-requests/', data);
    return response.data;
  },

  getUpdateRequests: async () => {
    const response = await api.get('/update-requests/');
    return response.data;
  },

  approveUpdateRequest: async (id) => {
    const response = await api.post(`/update-requests/${id}/approve/`);
    return response.data;
  },

  rejectUpdateRequest: async (id) => {
    const response = await api.post(`/update-requests/${id}/reject/`);
    return response.data;
  },
};
